﻿namespace Joe_s_automotive
{
    partial class Automotive
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.oIlLubeGroupBox = new System.Windows.Forms.GroupBox();
            this.lubeCheckBox = new System.Windows.Forms.CheckBox();
            this.oilCheckBox = new System.Windows.Forms.CheckBox();
            this.flushesGroupBox = new System.Windows.Forms.GroupBox();
            this.tranCheckBox = new System.Windows.Forms.CheckBox();
            this.radiatorCheckBox = new System.Windows.Forms.CheckBox();
            this.miscGroupBox = new System.Windows.Forms.GroupBox();
            this.tireCheckBox = new System.Windows.Forms.CheckBox();
            this.replaceCheckBox = new System.Windows.Forms.CheckBox();
            this.inspectionCheckBox = new System.Windows.Forms.CheckBox();
            this.partsAndLabourGroupBox = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.labourTextBox = new System.Windows.Forms.TextBox();
            this.partsTextBox = new System.Windows.Forms.TextBox();
            this.summaryGroupBox = new System.Windows.Forms.GroupBox();
            this.totalTextBox = new System.Windows.Forms.TextBox();
            this.taxTextBox = new System.Windows.Forms.TextBox();
            this.partTextBox = new System.Windows.Forms.TextBox();
            this.serviceTextBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.calculateButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.oIlLubeGroupBox.SuspendLayout();
            this.flushesGroupBox.SuspendLayout();
            this.miscGroupBox.SuspendLayout();
            this.partsAndLabourGroupBox.SuspendLayout();
            this.summaryGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // oIlLubeGroupBox
            // 
            this.oIlLubeGroupBox.Controls.Add(this.lubeCheckBox);
            this.oIlLubeGroupBox.Controls.Add(this.oilCheckBox);
            this.oIlLubeGroupBox.Location = new System.Drawing.Point(23, 18);
            this.oIlLubeGroupBox.Name = "oIlLubeGroupBox";
            this.oIlLubeGroupBox.Size = new System.Drawing.Size(327, 217);
            this.oIlLubeGroupBox.TabIndex = 0;
            this.oIlLubeGroupBox.TabStop = false;
            this.oIlLubeGroupBox.Text = "Oil Lube";
            // 
            // lubeCheckBox
            // 
            this.lubeCheckBox.AutoSize = true;
            this.lubeCheckBox.Location = new System.Drawing.Point(28, 110);
            this.lubeCheckBox.Name = "lubeCheckBox";
            this.lubeCheckBox.Size = new System.Drawing.Size(172, 24);
            this.lubeCheckBox.TabIndex = 1;
            this.lubeCheckBox.Text = "Lube Jobs ($18.00)";
            this.lubeCheckBox.UseVisualStyleBackColor = true;
            // 
            // oilCheckBox
            // 
            this.oilCheckBox.AutoSize = true;
            this.oilCheckBox.Location = new System.Drawing.Point(28, 43);
            this.oilCheckBox.Name = "oilCheckBox";
            this.oilCheckBox.Size = new System.Drawing.Size(121, 24);
            this.oilCheckBox.TabIndex = 0;
            this.oilCheckBox.Text = "Oil Changes";
            this.oilCheckBox.UseVisualStyleBackColor = true;
            // 
            // flushesGroupBox
            // 
            this.flushesGroupBox.Controls.Add(this.tranCheckBox);
            this.flushesGroupBox.Controls.Add(this.radiatorCheckBox);
            this.flushesGroupBox.Location = new System.Drawing.Point(356, 18);
            this.flushesGroupBox.Name = "flushesGroupBox";
            this.flushesGroupBox.Size = new System.Drawing.Size(345, 217);
            this.flushesGroupBox.TabIndex = 1;
            this.flushesGroupBox.TabStop = false;
            this.flushesGroupBox.Text = "Flushes";
            // 
            // tranCheckBox
            // 
            this.tranCheckBox.AutoSize = true;
            this.tranCheckBox.Location = new System.Drawing.Point(39, 110);
            this.tranCheckBox.Name = "tranCheckBox";
            this.tranCheckBox.Size = new System.Drawing.Size(230, 24);
            this.tranCheckBox.TabIndex = 1;
            this.tranCheckBox.Text = "Transmission Flush($80.00)";
            this.tranCheckBox.UseVisualStyleBackColor = true;
            // 
            // radiatorCheckBox
            // 
            this.radiatorCheckBox.AutoSize = true;
            this.radiatorCheckBox.Location = new System.Drawing.Point(39, 47);
            this.radiatorCheckBox.Name = "radiatorCheckBox";
            this.radiatorCheckBox.Size = new System.Drawing.Size(198, 24);
            this.radiatorCheckBox.TabIndex = 0;
            this.radiatorCheckBox.Text = "Radiator Flush($30.00)";
            this.radiatorCheckBox.UseVisualStyleBackColor = true;
            // 
            // miscGroupBox
            // 
            this.miscGroupBox.Controls.Add(this.tireCheckBox);
            this.miscGroupBox.Controls.Add(this.replaceCheckBox);
            this.miscGroupBox.Controls.Add(this.inspectionCheckBox);
            this.miscGroupBox.Location = new System.Drawing.Point(24, 241);
            this.miscGroupBox.Name = "miscGroupBox";
            this.miscGroupBox.Size = new System.Drawing.Size(326, 209);
            this.miscGroupBox.TabIndex = 2;
            this.miscGroupBox.TabStop = false;
            this.miscGroupBox.Text = "Misc.";
            // 
            // tireCheckBox
            // 
            this.tireCheckBox.AutoSize = true;
            this.tireCheckBox.Location = new System.Drawing.Point(32, 169);
            this.tireCheckBox.Name = "tireCheckBox";
            this.tireCheckBox.Size = new System.Drawing.Size(185, 24);
            this.tireCheckBox.TabIndex = 2;
            this.tireCheckBox.Text = "Tire Rotation($20.00)";
            this.tireCheckBox.UseVisualStyleBackColor = true;
            // 
            // replaceCheckBox
            // 
            this.replaceCheckBox.AutoSize = true;
            this.replaceCheckBox.Location = new System.Drawing.Point(32, 111);
            this.replaceCheckBox.Name = "replaceCheckBox";
            this.replaceCheckBox.Size = new System.Drawing.Size(215, 24);
            this.replaceCheckBox.TabIndex = 1;
            this.replaceCheckBox.Text = "Replace Muffler($100.00)";
            this.replaceCheckBox.UseVisualStyleBackColor = true;
            // 
            // inspectionCheckBox
            // 
            this.inspectionCheckBox.AutoSize = true;
            this.inspectionCheckBox.Location = new System.Drawing.Point(32, 52);
            this.inspectionCheckBox.Name = "inspectionCheckBox";
            this.inspectionCheckBox.Size = new System.Drawing.Size(168, 24);
            this.inspectionCheckBox.TabIndex = 0;
            this.inspectionCheckBox.Text = "Inspection($15.00)";
            this.inspectionCheckBox.UseVisualStyleBackColor = true;
            // 
            // partsAndLabourGroupBox
            // 
            this.partsAndLabourGroupBox.Controls.Add(this.label2);
            this.partsAndLabourGroupBox.Controls.Add(this.label1);
            this.partsAndLabourGroupBox.Controls.Add(this.labourTextBox);
            this.partsAndLabourGroupBox.Controls.Add(this.partsTextBox);
            this.partsAndLabourGroupBox.Location = new System.Drawing.Point(356, 241);
            this.partsAndLabourGroupBox.Name = "partsAndLabourGroupBox";
            this.partsAndLabourGroupBox.Size = new System.Drawing.Size(344, 208);
            this.partsAndLabourGroupBox.TabIndex = 3;
            this.partsAndLabourGroupBox.TabStop = false;
            this.partsAndLabourGroupBox.Text = "Parts And Labour";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(20, 115);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 20);
            this.label2.TabIndex = 3;
            this.label2.Text = "Labour($)";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(20, 52);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "Parts";
            // 
            // labourTextBox
            // 
            this.labourTextBox.Location = new System.Drawing.Point(123, 112);
            this.labourTextBox.Name = "labourTextBox";
            this.labourTextBox.Size = new System.Drawing.Size(135, 26);
            this.labourTextBox.TabIndex = 1;
            // 
            // partsTextBox
            // 
            this.partsTextBox.Location = new System.Drawing.Point(122, 52);
            this.partsTextBox.Name = "partsTextBox";
            this.partsTextBox.Size = new System.Drawing.Size(137, 26);
            this.partsTextBox.TabIndex = 0;
            // 
            // summaryGroupBox
            // 
            this.summaryGroupBox.Controls.Add(this.exitButton);
            this.summaryGroupBox.Controls.Add(this.totalTextBox);
            this.summaryGroupBox.Controls.Add(this.clearButton);
            this.summaryGroupBox.Controls.Add(this.taxTextBox);
            this.summaryGroupBox.Controls.Add(this.calculateButton);
            this.summaryGroupBox.Controls.Add(this.partTextBox);
            this.summaryGroupBox.Controls.Add(this.serviceTextBox);
            this.summaryGroupBox.Controls.Add(this.label6);
            this.summaryGroupBox.Controls.Add(this.label5);
            this.summaryGroupBox.Controls.Add(this.label4);
            this.summaryGroupBox.Controls.Add(this.label3);
            this.summaryGroupBox.Location = new System.Drawing.Point(23, 469);
            this.summaryGroupBox.Name = "summaryGroupBox";
            this.summaryGroupBox.Size = new System.Drawing.Size(677, 219);
            this.summaryGroupBox.TabIndex = 4;
            this.summaryGroupBox.TabStop = false;
            this.summaryGroupBox.Text = "Summary";
            // 
            // totalTextBox
            // 
            this.totalTextBox.Location = new System.Drawing.Point(215, 180);
            this.totalTextBox.Name = "totalTextBox";
            this.totalTextBox.Size = new System.Drawing.Size(189, 26);
            this.totalTextBox.TabIndex = 7;
            // 
            // taxTextBox
            // 
            this.taxTextBox.Location = new System.Drawing.Point(215, 138);
            this.taxTextBox.Name = "taxTextBox";
            this.taxTextBox.Size = new System.Drawing.Size(188, 26);
            this.taxTextBox.TabIndex = 6;
            // 
            // partTextBox
            // 
            this.partTextBox.Location = new System.Drawing.Point(217, 99);
            this.partTextBox.Name = "partTextBox";
            this.partTextBox.Size = new System.Drawing.Size(186, 26);
            this.partTextBox.TabIndex = 5;
            // 
            // serviceTextBox
            // 
            this.serviceTextBox.Location = new System.Drawing.Point(219, 57);
            this.serviceTextBox.Name = "serviceTextBox";
            this.serviceTextBox.Size = new System.Drawing.Size(184, 26);
            this.serviceTextBox.TabIndex = 4;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(46, 186);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(84, 20);
            this.label6.TabIndex = 3;
            this.label6.Text = "Total Fees";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(44, 144);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(110, 20);
            this.label5.TabIndex = 2;
            this.label5.Text = "Tax (On Parts)";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(45, 102);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 20);
            this.label4.TabIndex = 1;
            this.label4.Text = "Parts";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(36, 57);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(123, 20);
            this.label3.TabIndex = 0;
            this.label3.Text = "Services Labour";
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(551, 25);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(120, 38);
            this.calculateButton.TabIndex = 5;
            this.calculateButton.Text = "Calculate Total";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(551, 93);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(120, 38);
            this.clearButton.TabIndex = 6;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(551, 168);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(120, 38);
            this.exitButton.TabIndex = 7;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Automotive
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 830);
            this.Controls.Add(this.summaryGroupBox);
            this.Controls.Add(this.partsAndLabourGroupBox);
            this.Controls.Add(this.miscGroupBox);
            this.Controls.Add(this.flushesGroupBox);
            this.Controls.Add(this.oIlLubeGroupBox);
            this.Name = "Automotive";
            this.Text = "Automotive";
            this.oIlLubeGroupBox.ResumeLayout(false);
            this.oIlLubeGroupBox.PerformLayout();
            this.flushesGroupBox.ResumeLayout(false);
            this.flushesGroupBox.PerformLayout();
            this.miscGroupBox.ResumeLayout(false);
            this.miscGroupBox.PerformLayout();
            this.partsAndLabourGroupBox.ResumeLayout(false);
            this.partsAndLabourGroupBox.PerformLayout();
            this.summaryGroupBox.ResumeLayout(false);
            this.summaryGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox oIlLubeGroupBox;
        private System.Windows.Forms.CheckBox lubeCheckBox;
        private System.Windows.Forms.CheckBox oilCheckBox;
        private System.Windows.Forms.GroupBox flushesGroupBox;
        private System.Windows.Forms.CheckBox tranCheckBox;
        private System.Windows.Forms.CheckBox radiatorCheckBox;
        private System.Windows.Forms.GroupBox miscGroupBox;
        private System.Windows.Forms.CheckBox tireCheckBox;
        private System.Windows.Forms.CheckBox replaceCheckBox;
        private System.Windows.Forms.CheckBox inspectionCheckBox;
        private System.Windows.Forms.GroupBox partsAndLabourGroupBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox labourTextBox;
        private System.Windows.Forms.TextBox partsTextBox;
        private System.Windows.Forms.GroupBox summaryGroupBox;
        private System.Windows.Forms.TextBox totalTextBox;
        private System.Windows.Forms.TextBox taxTextBox;
        private System.Windows.Forms.TextBox partTextBox;
        private System.Windows.Forms.TextBox serviceTextBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
    }
}

