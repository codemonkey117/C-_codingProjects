﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Joe_s_automotive
{
    public partial class Automotive : Form
    {
        public Automotive()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            double oil = 0, lube = 0, radiator = 0, trans = 0, inspection = 0,
                muffler = 0, tire = 0;

            if(oilCheckBox.Checked == true)
            {
                oil = 26;
            }
            if(lubeCheckBox.Checked == true)
            {
                lube = 18;
            }
            if(radiatorCheckBox.Checked == true)
            {
                radiator = 30;
            }
            if(tranCheckBox.Checked == true)
            {
                trans = 80;
            }
            if(inspectionCheckBox.Checked == true)
            {
                inspection = 15;
            }
            if(replaceCheckBox.Checked == true)
            {
                muffler = 100;
            }
            if(tireCheckBox.Checked == true)
            {
                tire = 20;
            }

            double parts = double.Parse(partsTextBox.Text);
            double labour = double.Parse(labourTextBox.Text);

            double oillube = OilLubeCharges(oil, lube);
            double flush = FlushCharges(radiator, trans);
            double misc = MiscCharges(inspection, muffler, tire);
            double other = OtherCharges(parts, labour);
            double tax = TaxCharges(parts, labour, oillube, flush, misc, other);
            double total = TotalCharges(oillube, flush, misc, other, tax);
            double services = oillube + flush + misc;

            serviceTextBox.Text = services.ToString();
            partTextBox.Text = other.ToString();
            taxTextBox.Text = tax.ToString();
            totalTextBox.Text = total.ToString();
        }
        private double OilLubeCharges(double oil, double lube)
        {
            return oil + lube;
        }

        private double FlushCharges(double radiator, double trans)
        {
            return radiator + trans;
        }
        
        private double MiscCharges(double inspection, double tire, double muffler)
        {
            return inspection + muffler + tire;
        }

        private double OtherCharges(double parts, double labour)
        {
            return parts + labour;
        }

        private double TaxCharges(double parts, double labour, double oillube, double flush, double misc, double other)
        {
            if (parts != 0 && labour != 0 && (oillube != 0 && flush != 0 && misc != 0 && other != 0))
            {
                return (0.06 * parts);
            }
            else
                return 0;
        }

        private double TotalCharges(double oillube, double flush, double misc, double other, double tax)
        {
            return oillube + flush + misc + other + tax;
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            ClearOilLube();
            ClearFlushes();
            ClearMisc();
            ClearOther();
            ClearFees();
        }

        private void ClearOilLube()
        {
            if (oilCheckBox.Checked == true)
            {
                oilCheckBox.Checked = false;
            }
            if (lubeCheckBox.Checked == true)
            {
                lubeCheckBox.Checked = false;
            }
        }

        private void ClearFlushes ()
        {
            if (radiatorCheckBox.Checked == true)
            {
                radiatorCheckBox.Checked = false;
            }
            if (tranCheckBox.Checked == true)
            {
                tranCheckBox.Checked = false;
            }
        }

        private void ClearMisc()
        {
            if (inspectionCheckBox.Checked == true)
            {
                inspectionCheckBox.Checked = false;
            }
            if (replaceCheckBox.Checked == true)
            {
                replaceCheckBox.Checked = false;
            }
            if (tireCheckBox.Checked == true)
            {
                tireCheckBox.Checked = false;
            }
        }

        private void ClearOther ()
        {
            partsTextBox.Text = null;
            labourTextBox.Text = null;
        }

        private void ClearFees ()
        {
            serviceTextBox.Text = null;
            partTextBox.Text = null;
            taxTextBox.Text = null;
            totalTextBox.Text = null;
        }
    }
}
       
