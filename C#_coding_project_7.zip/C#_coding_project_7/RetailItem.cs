﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RetailItems_Class
{
    internal class RetailItem
    {
        string description;
        int unitOnHands;
        double price;

        public RetailItem(string description, int unitOnHands, double price)
        {
            this.description = description;
            this.unitOnHands = unitOnHands;
            this.price = price;
        }

        public string Description
        {
            get
            {
                return description;
            }

            set
            {
                description = value;
            }
        }

        public int UnitOnHands
        {
            get
            {
                return unitOnHands;
            }

            set
            {
                unitOnHands = value;
            }
        }

        public double Price
        {
            get
            {
                return price;
            }

            set
            {
                price = value;
            }
        }

    }
}
