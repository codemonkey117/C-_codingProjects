﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RetailItems_Class
{
    public partial class Form1 : Form
    {
        RetailItem[] items;
        public Form1()
        {
            InitializeComponent();
            CreateItemArray();
        }

        private void CreateItemArray()
        {
            RetailItem item1 = new RetailItem("Jacket", 12, 59.95);
            RetailItem item2 = new RetailItem("Jeans", 40, 34.95);
            RetailItem item3 = new RetailItem("Shirt", 20, 24.95);

            items = new RetailItem[] { item1, item2, item3 };

            String output = "Description\tUnitOnHands\tPrice\n\n";

            foreach (RetailItem i in items)
            {
                output += i.Description + "\t\t" + i.UnitOnHands + "\t\t" + i.Price + Environment.NewLine;

            }

            

        }

        private void refreshButton_Click(object sender, EventArgs e)
        {
            itemListBox.Items.Clear();

            //For the life of me I cannot figure out how to pass the return value of the create array method into a click_event. 
            //That is the first reason I could guess as to why my code isnt working. 

        }
    }
}
