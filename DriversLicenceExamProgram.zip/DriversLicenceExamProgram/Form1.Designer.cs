﻿namespace drivers_licence_exam
{
    partial class driversExam
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gradeExamButton = new System.Windows.Forms.Button();
            this.missedQuestionListBox = new System.Windows.Forms.ListBox();
            this.correctLabel = new System.Windows.Forms.Label();
            this.incorrectLabel = new System.Windows.Forms.Label();
            this.openStudentFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.resultTextBox = new System.Windows.Forms.TextBox();
            this.incorrectTextBox = new System.Windows.Forms.TextBox();
            this.correctTextBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // gradeExamButton
            // 
            this.gradeExamButton.Location = new System.Drawing.Point(537, 393);
            this.gradeExamButton.Name = "gradeExamButton";
            this.gradeExamButton.Size = new System.Drawing.Size(137, 32);
            this.gradeExamButton.TabIndex = 0;
            this.gradeExamButton.Text = "Grade Exam";
            this.gradeExamButton.UseVisualStyleBackColor = true;
            this.gradeExamButton.Click += new System.EventHandler(this.gradeExamButton_Click);
            // 
            // missedQuestionListBox
            // 
            this.missedQuestionListBox.FormattingEnabled = true;
            this.missedQuestionListBox.ItemHeight = 20;
            this.missedQuestionListBox.Location = new System.Drawing.Point(191, 139);
            this.missedQuestionListBox.Name = "missedQuestionListBox";
            this.missedQuestionListBox.Size = new System.Drawing.Size(266, 204);
            this.missedQuestionListBox.TabIndex = 1;
            // 
            // correctLabel
            // 
            this.correctLabel.AutoSize = true;
            this.correctLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.correctLabel.Location = new System.Drawing.Point(54, 37);
            this.correctLabel.Name = "correctLabel";
            this.correctLabel.Size = new System.Drawing.Size(99, 29);
            this.correctLabel.TabIndex = 2;
            this.correctLabel.Text = "Correct";
            // 
            // incorrectLabel
            // 
            this.incorrectLabel.AutoSize = true;
            this.incorrectLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.incorrectLabel.Location = new System.Drawing.Point(623, 37);
            this.incorrectLabel.Name = "incorrectLabel";
            this.incorrectLabel.Size = new System.Drawing.Size(125, 29);
            this.incorrectLabel.TabIndex = 3;
            this.incorrectLabel.Text = "Dishonor ";
            // 
            // openStudentFileDialog
            // 
            this.openStudentFileDialog.FileName = "openFileDialog1";
            // 
            // resultTextBox
            // 
            this.resultTextBox.Location = new System.Drawing.Point(478, 192);
            this.resultTextBox.Name = "resultTextBox";
            this.resultTextBox.Size = new System.Drawing.Size(270, 26);
            this.resultTextBox.TabIndex = 4;
            this.resultTextBox.Text = "Results: ";
            // 
            // incorrectTextBox
            // 
            this.incorrectTextBox.Location = new System.Drawing.Point(628, 69);
            this.incorrectTextBox.Name = "incorrectTextBox";
            this.incorrectTextBox.Size = new System.Drawing.Size(120, 26);
            this.incorrectTextBox.TabIndex = 5;
            // 
            // correctTextBox
            // 
            this.correctTextBox.Location = new System.Drawing.Point(59, 69);
            this.correctTextBox.Name = "correctTextBox";
            this.correctTextBox.Size = new System.Drawing.Size(100, 26);
            this.correctTextBox.TabIndex = 6;
            // 
            // driversExam
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.correctTextBox);
            this.Controls.Add(this.incorrectTextBox);
            this.Controls.Add(this.resultTextBox);
            this.Controls.Add(this.incorrectLabel);
            this.Controls.Add(this.correctLabel);
            this.Controls.Add(this.missedQuestionListBox);
            this.Controls.Add(this.gradeExamButton);
            this.Name = "driversExam";
            this.Text = "Driver\'s Exam";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button gradeExamButton;
        private System.Windows.Forms.ListBox missedQuestionListBox;
        private System.Windows.Forms.Label correctLabel;
        private System.Windows.Forms.Label incorrectLabel;
        private System.Windows.Forms.OpenFileDialog openStudentFileDialog;
        private System.Windows.Forms.TextBox resultTextBox;
        private System.Windows.Forms.TextBox incorrectTextBox;
        private System.Windows.Forms.TextBox correctTextBox;
    }
}

