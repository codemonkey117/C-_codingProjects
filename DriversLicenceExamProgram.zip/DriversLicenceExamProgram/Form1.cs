﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace drivers_licence_exam
{
    public partial class driversExam : Form
    {
            public driversExam()
            {
                InitializeComponent();
            }

            private void gradeExamButton_Click(object sender, EventArgs e)
            {
                try {
                    missedQuestionListBox.Items.Clear();

                    const int SIZE = 20;
                    string[] examAnswers = new string[SIZE];
                    string[] studentAnswers = new string[SIZE];
                    examAnswers = ExamAnswers();
                    studentAnswers = GetStudentAnswers();
                    GradeExam(examAnswers, studentAnswers);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

            }

            private string[] ExamAnswers()
            {
                string[] examAnswers = new string[]{ "B", "D", "A", "A", "C", "A",
                    "B", "A", "C", "D", "B", "C", "D",
                    "A", "D", "C", "C", "B", "D", "A" };
                return examAnswers;
            }

            private string[] GetStudentAnswers()
            {
                const int SIZE = 20;
                string[] studentAnswers = new string[SIZE];

                int index = 0;

                StreamReader inputFile;

                if (openStudentFileDialog.ShowDialog() != DialogResult.OK)
                    return null;
                inputFile = File.OpenText("StudentAnswers.txt");

                while (index < studentAnswers.Length && !inputFile.EndOfStream)
                {
                    studentAnswers[index] = inputFile.ReadLine();
                    index++;
                }
                return studentAnswers;
            }

            private void GradeExam(string[] examAnswers, string[] studentAnswers)
            {
                int correctCount = 0;
                int incorrectCount = 0;
                List<int> incorrectQuestions = new List<int>();

                for (int i = 0; i < 20; i++)
                {
                    if (studentAnswers[i] == examAnswers[i])
                    {
                        correctCount++;
                    }
                    else
                    {
                        incorrectCount++;
                        incorrectQuestions.Add(i + 1);
                    }
                }
                
                if (correctCount >= 15)
                {
                resultTextBox.AppendText("You Passed!");
                }
                else
                {
                resultTextBox.AppendText("Licence permission Revoked!");
                }
                
                correctTextBox.Text = "Correct answers:" + correctCount;
                incorrectTextBox.Text = "Incorrect answers:" + incorrectCount;

                if (incorrectCount > 0)
                {
                missedQuestionListBox.Text = "Missed Questions";
                foreach(int questions in incorrectQuestions)
                    {
                    missedQuestionListBox.Items.Add(questions);
                    }
                }
            }
            
            
    }
}
