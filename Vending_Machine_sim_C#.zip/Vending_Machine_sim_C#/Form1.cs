﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vending_machine_simulator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public struct soft_drink
        {

            public string drink_name;

            public float cost;

            public int drink_stock;

        }
        public static class softDrink
        {
            public static soft_drink[] soft = new soft_drink[5];
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (radioButton1.Checked)

            {

                softDrink.soft[0].drink_stock = softDrink.soft[0].drink_stock - 1;

                if (softDrink.soft[0].drink_stock >= 0)

                {

                    label5.Text = softDrink.soft[0].drink_name;

                    label6.Text = Convert.ToString(softDrink.soft[0].cost);

                    label7.Text = Convert.ToString(softDrink.soft[0].drink_stock);

                    label8.Visible = false;

                }

                else

                {

                    label8.Visible = true;

                    label8.Text = "Out of stock";

                }

            }

            else if (radioButton2.Checked)

            {

                softDrink.soft[1].drink_stock = softDrink.soft[1].drink_stock - 1;

                if (softDrink.soft[1].drink_stock >= 0)

                {

                    label5.Text = softDrink.soft[1].drink_name;

                    label6.Text = Convert.ToString(softDrink.soft[1].cost);

                    label7.Text = Convert.ToString(softDrink.soft[1].drink_stock);

                    label8.Visible = false;

                }

                else

                {

                    label8.Visible = true;

                    label8.Text = "Out of stock";

                }

            }

            else if (radioButton3.Checked)

            {

                softDrink.soft[2].drink_stock = softDrink.soft[2].drink_stock - 1;

                if (softDrink.soft[2].drink_stock >= 0)

                {

                    label5.Text = softDrink.soft[2].drink_name;

                    label6.Text = Convert.ToString(softDrink.soft[2].cost);

                    label7.Text = Convert.ToString(softDrink.soft[2].drink_stock);

                    label8.Visible = false;

                }

                else

                {

                    label8.Visible = true;

                    label8.Text = "Out of stock";

                }

            }

            else if (radioButton4.Checked)

            {

                softDrink.soft[3].drink_stock = softDrink.soft[3].drink_stock - 1;

                if (softDrink.soft[3].drink_stock >= 0)

                {

                    label5.Text = softDrink.soft[3].drink_name;

                    label6.Text = Convert.ToString(softDrink.soft[3].cost);

                    label7.Text = Convert.ToString(softDrink.soft[3].drink_stock);

                    label8.Visible = false;

                }

                else

                {

                    label8.Visible = true;

                    label8.Text = "Out of stock";

                }

            }

            else if (radioButton5.Checked)

            {

                softDrink.soft[4].drink_stock = softDrink.soft[4].drink_stock - 1;

                if (softDrink.soft[4].drink_stock >= 0)

                {

                    label5.Text = softDrink.soft[4].drink_name;

                    label6.Text = Convert.ToString(softDrink.soft[4].cost);

                    label7.Text = Convert.ToString(softDrink.soft[4].drink_stock);

                    label8.Visible = false;

                }

                else

                {

                    label8.Visible = true;

                    label8.Text = "Out of stock";

                }

            }

            else

            {

                label8.Visible = true;

                label8.Text = "First select any soft drink";

            }

        }
        public void radioButton1_CheckedChanged(object sender, EventArgs e)

        {

            label5.Text = softDrink.soft[0].drink_name;

            label6.Text = Convert.ToString(softDrink.soft[0].cost);

            label7.Text = Convert.ToString(softDrink.soft[0].drink_stock);

        }

        public void radioButton2_CheckedChanged(object sender, EventArgs e)

        {

            label5.Text = softDrink.soft[1].drink_name;

            label6.Text = Convert.ToString(softDrink.soft[1].cost);

            label7.Text = Convert.ToString(softDrink.soft[1].drink_stock);

        }

        public void radioButton3_CheckedChanged(object sender, EventArgs e)

        {

            label5.Text = softDrink.soft[2].drink_name;

            label6.Text = Convert.ToString(softDrink.soft[2].cost);

            label7.Text = Convert.ToString(softDrink.soft[2].drink_stock);

        }

        public void radioButton4_CheckedChanged(object sender, EventArgs e)

        {

            label5.Text = softDrink.soft[3].drink_name;

            label6.Text = Convert.ToString(softDrink.soft[3].cost);

            label7.Text = Convert.ToString(softDrink.soft[3].drink_stock);

        }

        public void radioButton5_CheckedChanged(object sender, EventArgs e)

        {

            label5.Text = softDrink.soft[4].drink_name;

            label6.Text = Convert.ToString(softDrink.soft[4].cost);

            label7.Text = Convert.ToString(softDrink.soft[4].drink_stock);

        }
        public void Form1_Load(object sender, EventArgs e)

        {

            label8.Visible = false;

            softDrink.soft[0].drink_name = "Cola";

            softDrink.soft[0].cost = 1;

            softDrink.soft[0].drink_stock = 20;

            softDrink.soft[1].drink_name = "Root Bear";

            softDrink.soft[1].cost = 1;

            softDrink.soft[1].drink_stock = 20;

            softDrink.soft[2].drink_name = "Lemon Lime Soda";

            softDrink.soft[2].cost = 1;

            softDrink.soft[2].drink_stock = 20;

            softDrink.soft[3].drink_name = "Grap Soda";

            softDrink.soft[3].cost = 1.5f;

            softDrink.soft[3].drink_stock = 20;

            softDrink.soft[4].drink_name = "Cream Soda";

            softDrink.soft[4].cost = 1.5f;

            softDrink.soft[4].drink_stock = 20;

        }
    }
}
