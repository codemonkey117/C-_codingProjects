﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace population_counter
{
    public partial class frmPopulation : Form
    {
        public frmPopulation()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            int noOfPeople;

            int avgIncrease;

            int noYears;

            int count = 1;
            
            double approximatePopulation;




            lstPopulation.Items.Clear();

            if (!string.IsNullOrEmpty(txtNoOfPeople.Text) && !string.IsNullOrEmpty(txtAvgIncrease.Text) && !string.IsNullOrEmpty(txtNoOfYears.Text))

            {

                noOfPeople = Convert.ToInt32(txtNoOfPeople.Text);


                avgIncrease = Convert.ToInt32(txtAvgIncrease.Text);
                noYears = Convert.ToInt32(txtNoOfYears.Text);
                approximatePopulation = noOfPeople;

                lstPopulation.Items.Add("year" + "\t" + "--population");

                while (count <= noYears)

                   {
                    

                    lstPopulation.Items.Add(count.ToString() + "\t" + approximatePopulation.ToString());


                    approximatePopulation = approximatePopulation + (approximatePopulation * avgIncrease / 100);


                    count++;

                   }

            }

        }    
    }
}